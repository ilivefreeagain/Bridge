getImageUrl = function(item)
    return string.format('https://cfx-nui-core_inventory/html/img/%s.png', item)
end