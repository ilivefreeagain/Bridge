canCarryitem = function(src, data)
    return true -- Ox Handles inside base events
end

hasItem = function(src, data)
    return true -- Ox Handles inside base events
end

addItem = function(src, data)
    data.count = data?.count or 1

    local success, response = exports.ox_inventory:AddItem(src, data.item, data.count, data.metadata, data.slot, cb)
    if not success then 
        return success
    end
    return success
end

removeItem = function(src, data)
    data.count = data?.count or 1

    local success, response = exports.ox_inventory:RemoveItem(src, data.item, data.count, data.metadata, data.slot, true)
    if not success then
        return success
    end
    return success
end