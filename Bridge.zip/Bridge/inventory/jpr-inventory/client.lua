getImageUrl = function(item)
    return string.format('https://cfx-nui-jpr-inventory/html/images/%s.png', item)
end
