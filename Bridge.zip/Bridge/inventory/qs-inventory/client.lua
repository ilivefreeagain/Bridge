getImageUrl = function(item)
    return string.format('https://cfx-nui-qs-inventory/html/images/%s.png', item)
end