canCarryitem = function(src, data)
    return true
end

hasItem = function(src, data)
    return exports["ls-inventory"]:HasItem(src, data.item, data.count)
end

addItem = function(src, data)
    data.count = data?.count or 1
    local success = canCarryitem(src, data)
    if not success then
        return success
    end

    local success = exports['ls-inventory']:AddItem(src, data.item, data.count, data.slot, data.metadata)
    if not success then 
        return success 
    end

    return success
end

removeItem = function(src, data)
    data.count = data?.count or 1
    local success, response = hasItem(src, data)
    if not success then
        return success, {err = response.err}
    end

    local success = exports['ls-inventory']:RemoveItem(src, data.item, data.count, data.slot)
    if not success then
        return success, {err = "Failed to remove item"}
    end

    return success
end

