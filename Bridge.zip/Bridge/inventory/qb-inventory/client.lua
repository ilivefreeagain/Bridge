getImageUrl = function(item)
    return string.format('https://cfx-nui-qb-inventory/html/images/%s.png', item)
end