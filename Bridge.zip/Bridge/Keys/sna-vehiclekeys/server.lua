AddKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    TriggerServerEvent('sna-vehiclekeys:server:GiveTempKey', plate)
    return true
end

RemoveKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    TriggerEvent('sna-vehiclekeys:server:RemoveKey', plate)
    return true
end
