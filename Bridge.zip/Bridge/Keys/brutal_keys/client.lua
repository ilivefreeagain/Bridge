AddKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    exports.brutal_keys:addVehicleKey(plate, "Taxi Keys")
    return true
end

RemoveKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    exports.brutal_keys:removeKey(plate, true)
    return true
end