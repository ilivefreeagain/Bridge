AddKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end
    local model = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))
    local plate = GetVehicleNumberPlateText(vehicle)
    
    exports['qs-vehiclekeys']:GiveKeys(plate, model, true)
    return true
end

RemoveKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local model = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))
    local plate = GetVehicleNumberPlateText(vehicle)

    exports['qs-vehiclekeys']:RemoveKeys(plate, model)
    return true
end