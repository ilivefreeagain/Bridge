AddKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    TriggerServerEvent('qb-vehiclekeys:server:AcquireVehicleKeys', plate)
    return true
end

RemoveKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    return true
end