
AddKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    exports.MrNewbVehicleKeys:GiveKeys(vehicle)
    return true
end

RemoveKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    exports.MrNewbVehicleKeys:RemoveKeys(vehicle)
    return true
end