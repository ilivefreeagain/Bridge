AddKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    return exports['Renewed-Vehiclekeys']:addKey(plate)
end

RemoveKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    exports['Renewed-Vehiclekeys']:removeKey(plate)
    return true
end