AddKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    exports.wasabi_carlock:GiveKey(plate)
    return true
end

RemoveKeys = function(vehicle)
    if not DoesEntityExist(vehicle) then 
        return false 
    end

    local plate = GetVehicleNumberPlateText(vehicle)
    exports.wasabi_carlock:RemoveKey(plate)
    return true
end