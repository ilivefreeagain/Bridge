This bridge is for jobs that need to function with other scripts. open the folder you want to use to copy the trigger to add to your script where needed.

to test drive car u need to give keys and remove keys after test drive is done.
to sell a car you need to give key as part of the sale for new cars. 
for used cars you need to remove keys from ID and give them to the new ID.

more to this bridge setup is coming soon. 
    city hall intergrations
    mechantic job to add engine sounds, pictures and additional parts to install.
    