getFuel = function(veh)
    return exports['okokGasStation']:GetFuel(veh)
end


setFuel = function(veh, val)
    return exports['okokGasStation']:SetFuel(veh, val)
end