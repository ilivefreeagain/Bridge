getFuel = function(veh)
    return exports['cdn-fuel']:GetFuel(veh, val)
end


setFuel = function(veh, val)
    return exports['cdn-fuel']:SetFuel(veh)
end
