getFuel = function(veh)
    return exports['qs-fuelstations']:GetFuel(veh)
end


setFuel = function(veh, val)
    return exports['qs-fuelstations']:SetFuel(veh, val)
end