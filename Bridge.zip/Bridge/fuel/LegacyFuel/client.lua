getFuel = function(veh)
    return exports['LegacyFuel']:GetFuel(veh)
end

setFuel = function(veh, val)
    return exports['LegacyFuel']:SetFuel(veh, val)
end