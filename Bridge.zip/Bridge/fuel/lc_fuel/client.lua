getFuel = function(veh)
    return exports["lc_fuel"]:GetFuel(veh)
end

setFuel = function(veh, val)
    return exports["lc_fuel"]:SetFuel(veh, val)
end