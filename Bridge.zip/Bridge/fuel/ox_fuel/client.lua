getFuel = function(veh)
    return Entity(veh).state.fuel
end


setFuel = function(veh, val)
    Entity(veh).state.fuel = val
    return true
end