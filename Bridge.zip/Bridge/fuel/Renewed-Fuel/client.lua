getFuel = function(veh)
    return exports['Renewed-Fuel']:GetFuel(veh)
end


setFuel = function(veh, val)
    return exports['Renewed-Fuel']:SetFuel(veh, val)
end