getFuel = function(veh)
    return exports['x-fuel']:GetFuel(veh)
end

setFuel = function(veh, val)
    return exports['x-fuel']:SetFuel(veh, val)
end