getFuel = function(veh)
    return exports['ps-fuel']:GetFuel(veh, val)
end


setFuel = function(veh, val)
    return exports['ps-fuel']:SetFuel(veh, val)
end