getFuel = function(veh)
    return exports["rcore_fuel"]:GetVehicleFuelLiters(veh)
end

setFuel = function(veh, val)
    return exports["rcore_fuel"]:SetVehicleFuel(veh, val)
end
