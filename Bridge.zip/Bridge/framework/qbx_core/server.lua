local qbx_core = exports['qbx_core']
local ox_inventory = exports['ox_inventory']

-- @param source number | The player source.
-- @return string | The player's citizen ID.
GetIdentifier = function(source)
    if not source then return nil end
    local player = qbx_core:GetPlayer(source)
    if not player then return nil end
    return player.PlayerData.citizenid
end

-- @param source number | The player source.
-- @return string | The player's full name.
GetName = function(source)
    local player = qbx_core:GetPlayer(source)
    if not player then return "" end
    return player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname
end

-- @param identifier string | The player's unique identifier.
-- @return string The player's full name.
GetNameByIdentifier = function(identifier)
    if identifier then
        local result = MySQL.query.await('SELECT charinfo FROM players WHERE citizenid = ?', { identifier })
        if result and result[1] then
            local charInfo = json.decode(result[1].charinfo)
            return charInfo.firstname .. ' ' .. charInfo.lastname
        end
    end
    identifier = identifier or "No Id"
    return "No Name Found - " .. identifier
end

-- @param source number | The player source.
-- @param job string | The job name to check for.
-- @return number | The number of players with the specified job.
GetJobCount = function(source, job)
    local amount = 0
    local players = qbx_core:GetQBPlayers()
    for _, v in pairs(players) do
        if v and v.PlayerData.job.name == job then
            amount = amount + 1
        end
    end
    return amount
end

-- @return table | A table of all players with job and gang information.
GetPlayers = function()
    local players = qbx_core:GetQBPlayers()
    local formattedPlayers = {}
    for _, v in pairs(players) do
        local player = {
            job = v.PlayerData.job.name,
            gang = v.PlayerData.gang.name,
            source = v.PlayerData.source
        }
        table.insert(formattedPlayers, player)
    end
    return formattedPlayers
end

-- @param source number | The player source.
-- @return table | The player's job and gang data.
GetPlayerGroups = function(source)
    local player = qbx_core:GetPlayer(source)
    return player.PlayerData.job, player.PlayerData.gang
end

-- @param source number | The player source.
-- @return table | The player's job info, including name, label, grade, and grade name.
GetPlayerJobInfo = function(source)
    local player = qbx_core:GetPlayer(source)
    local job = player.PlayerData.job
    return {
        name = job.name,
        label = job.label,
        grade = job.grade,
        gradeName = job.grade.name,
    }
end

-- @param source number | The player source.
-- @return table | The player's gang info, including name, label, grade, and grade name.
GetPlayerGangInfo = function(source)
    local player = qbx_core:GetPlayer(source)
    local gang = player.PlayerData.gang
    return {
        name = gang.name,
        label = gang.label,
        grade = gang.grade,
        gradeName = gang.grade.name,
    }
end

-- @param source number | The player source.
-- @return string | The player's date of birth.
GetDob = function(source)
    local player = qbx_core:GetPlayer(source)
    return player.PlayerData.charinfo.birthdate
end

-- @param source number | The player source.
-- @return string | The player's gender.
GetSex = function(source)
    local player = qbx_core:GetPlayer(source)
    return player.PlayerData.charinfo.gender
end

-- @param source number | The player source.
-- @param item string | The item to remove.
-- @param count number | The number of items to remove.
-- @return boolean | Whether the item was successfully removed.
RemoveItem = function(source, item, count)
    return ox_inventory:RemoveItem(source, item, count)
end

-- @param source number | The player source.
-- @param item string | The item to add.
-- @param count number | The number of items to add.
-- @return boolean | Whether the item was successfully added.
AddItem = function(source, item, count)
    return ox_inventory:AddItem(source, item, count)
end

-- @param source number | The player source.
-- @param _item string | The item name to check.
-- @return number | The number of items the player has.
HasItem = function(source, _item)
    local player = qbx_core:GetPlayer(source)
    local item = player.Functions.GetItemByName(_item)
    return item and (item.count or item.amount or 0)
end

-- @param source number | The player source.
-- @return table | A list of items in the player's inventory, including name, label, count, weight, and metadata.
GetInventory = function(source)
    local items = {}
    local data = ox_inventory:GetInventoryItems(source)
    for slot, item in pairs(data) do
        table.insert(items, {
            name = item.name,
            label = item.label,
            count = item.count,
            weight = item.weight,
            metadata = item.metadata
        })
    end
    return items
end

GetItemData = function(item)
    return "Item Data" -- Qbox Inventory Handles This
end

-- @param item string | The item to register as usable.
-- @param cb function | The callback function to trigger when the item is used.
-- @return void
RegisterUsableItem = function(item, cb)
    qbx_core:CreateUseableItem(item, cb)
end

GetMoney = function(source, accountname)
    local Player = qbx_core:GetPlayer(source).PlayerData
    if accountname == 'cash' then
        return Player.money.cash
    elseif accountname == 'bank' then
        return Player.money.bank
    end
end

AddMoney = function(source, accountname, amount, reason)
    local Player = qbx_core:GetPlayer(source)
    if accountname == 'cash' then
        return Player.Functions.AddMoney('cash', amount, reason)
    elseif accountname == 'bank' then
        return Player.Functions.AddMoney('bank', amount, reason)
    end
end

RemoveMoney = function(source, accountname, amount, reason)
    local Player = qbx_core:GetPlayer(source)
    if accountname == 'cash' then
        return Player.Functions.RemoveMoney('cash', amount, reason)
    elseif accountname == 'bank' then
        return Player.Functions.RemoveMoney('bank', amount, reason)
    end
end
