local QBCore = exports['qb-core']:GetCoreObject()
local ox_inventory = GetResourceState('ox_inventory') == 'started' and true or false

-- @param source number | The player's server ID.
-- @return string The player's unique identifier.
GetIdentifier = function(source)
    if not source then return nil end
    local player = QBCore.Functions.GetPlayer(source)
    if not player then return nil end
    return player.PlayerData.citizenid
end

-- @param source number | The player's server ID.
-- @return string The player's full name.
GetName = function(source)
    local player = QBCore.Functions.GetPlayer(source)
    if not player then return "" end
    return player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname
end

-- @param identifier string | The player's unique identifier.
-- @return string The player's full name.
GetNameByIdentifier = function(identifier)
    if identifier then
        local result = MySQL.query.await('SELECT charinfo FROM players WHERE citizenid = ?', { identifier })
        if result and result[1] then
            local charInfo = json.decode(result[1].charinfo)
            return charInfo.firstname .. ' ' .. charInfo.lastname
        end
    end
    identifier = identifier or "No Id"
    return "No Name Found - " .. identifier
end


-- @param source number | The player's server ID.
-- @param job string | The job name to count.
-- @return number The count of players with the specified job.
GetJobCount = function(source, job)
    local amount = 0
    local players = QBCore.Functions.GetQBPlayers()
    for _, v in pairs(players) do
        if v and v.PlayerData.job.name == job then
            amount = amount + 1
        end
    end
    return amount
end

-- @return table A list of formatted player data.
GetPlayers = function()
    local players = QBCore.Functions.GetQBPlayers()
    local formattedPlayers = {}
    for _, v in pairs(players) do
        local player = {
            job = v.PlayerData.job.name,
            gang = v.PlayerData.gang.name,
            source = v.PlayerData.source
        }
        table.insert(formattedPlayers, player)
    end
    return formattedPlayers
end

-- @param source number | The player's server ID.
-- @return table The player's job and gang data.
GetPlayerGroups = function(source)
    local player = QBCore.Functions.GetPlayer(source)
    return player.PlayerData.job, player.PlayerData.gang
end

-- @param source number | The player's server ID.
-- @return table The player's job details.
GetPlayerJobInfo = function(source)
    local player = QBCore.Functions.GetPlayer(source)
    local job = player.PlayerData.job
    return {
        name = job.name,
        label = job.label,
        grade = job.grade,
        gradeName = job.grade.name,
    }
end

-- @param source number | The player's server ID.
-- @return table The player's gang details.
GetPlayerGangInfo = function(source)
    local player = QBCore.Functions.GetPlayer(source)
    local gang = player.PlayerData.gang
    return {
        name = gang.name,
        label = gang.label,
        grade = gang.grade,
        gradeName = gang.grade.name,
    }
end

-- @param source number | The player's server ID.
-- @return string The player's date of birth.
GetDob = function(source)
    local player = QBCore.Functions.GetPlayer(source)
    return player.PlayerData.charinfo.birthdate
end

-- @param source number | The player's server ID.
-- @return string The player's gender.
GetSex = function(source)
    local player = QBCore.Functions.GetPlayer(source)
    return player.PlayerData.charinfo.gender
end

-- @param source number | The player's server ID.
-- @param item string | The item to remove.
-- @param count number | The quantity to remove.
-- @return boolean Whether the item was successfully removed.
RemoveItem = function(source, item, count)
    local player = QBCore.Functions.GetPlayer(source)
    return player.Functions.RemoveItem(item, count)
end

-- @param source number | The player's server ID.
-- @param item string | The item to add.
-- @param count number | The quantity to add.
-- @return boolean Whether the item was successfully added.
AddItem = function(source, item, count)
    local player = QBCore.Functions.GetPlayer(source)
    return player.Functions.AddItem(item, count)
end

-- @param source number | The player's server ID.
-- @param _item string | The item to check.
-- @return number The quantity of the item the player has.
HasItem = function(source, _item)
    local player = QBCore.Functions.GetPlayer(source)
    local item = player.Functions.GetItemByName(_item)
    return item and (item.count or item.amount or 0)
end

-- @param source number | The player's server ID.
-- @return table A list of the player's inventory items.
GetInventory = function(source)
    local player = QBCore.Functions.GetPlayer(source)
    local items = {}
    local data = ox_inventory and exports.ox_inventory:GetInventoryItems(source) or player.PlayerData.items
    for slot, item in pairs(data) do
        table.insert(items, {
            name = item.name,
            label = item.label,
            count = ox_inventory and item.count or item.amount,
            weight = item.weight,
            metadata = ox_inventory and item.metadata or item.info
        })
    end
    return items
end

GetItemData = function(item)
    local data = QBCore.Shared.Items[item]
    if not data then
        item = item or "No Item"
    end
    return data
end

-- @param item string | The item to register as usable.
-- @param cb function | The callback function to execute when the item is used.
RegisterUsableItem = function(item, cb)
    QBCore.Functions.CreateUseableItem(item, cb)
end

GetMoney = function(source, accountname)
    local player = QBCore.Functions.GetPlayer(source)
    local data = player.PlayerData
    if accountname == 'cash' then
        return data.money['cash']
    elseif accountname == 'bank' then
        return data.money['bank']
    end
end

AddMoney = function(source, accountname, amount, reason)
    local player = QBCore.Functions.GetPlayer(source)
    if accountname == 'cash' then
        return player.Functions.AddMoney('cash', amount, reason)
    elseif accountname == 'bank' then
        return player.Functions.AddMoney('bank', amount, reason)
    end
end

RemoveMoney = function(source, accountname, amount, reason)
    local player = QBCore.Functions.GetPlayer(source)
    if accountname == 'cash' then
        return player.Functions.RemoveMoney('cash', amount, reason)
    elseif accountname == 'bank' then
        return player.Functions.RemoveMoney('bank', amount, reason)
    end
end
