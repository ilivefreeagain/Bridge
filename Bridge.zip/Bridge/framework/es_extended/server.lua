local ESX = exports.es_extended:getSharedObject()
local ox_inventory = GetResourceState('ox_inventory') == 'started' and true or false

--- Get the player's identifier.
-- @param source number: The player's server ID.
-- @return string: The player's identifier.
GetIdentifier = function(source)
    if not source then return nil end
    local player = ESX.GetPlayerFromId(source)
    if not player then return nil end
    return player.getIdentifier()
end

--- Get the player's name.
-- @param source number: The player's server ID.
-- @return string: The player's name.
GetName = function(source)
    local player = ESX.GetPlayerFromId(source)
    if not player then return "" end
    return player.getName()
end

-- @param identifier string | The player's unique identifier.
-- @return string The player's full name.
GetNameByIdentifier = function(identifier)
    if identifier then
        local result = MySQL.query.await('SELECT firstname, lastname FROM users WHERE identifier = ?', { identifier })
        if result and result[1] then
            local fn, ln = result[1].firstname, result[1].lastname
            local name = fn..' '..ln
            return name
        end
    end
    identifier = identifier or "No Id"
    return "No Name Found - " .. identifier
end

GetItemData = function(item)
    return "Item Data" -- ESX inventories handle this
end

--- Get the count of players with a specific job.
-- @param source number: The player's server ID.
-- @param job string: The job name to search for.
-- @return table: A list of players with the given job.
GetJobCount = function(source, job)
    return ESX.GetExtendedPlayers('job', job)
end

--- Get the player's group/job information.
-- @param source number: The player's server ID.
-- @return string, boolean: The player's job name and gang status (always false).
GetPlayerGroups = function(source)
    local player = ESX.GetPlayerFromId(source)
    local job = player.getJob()
    return job.name, false
end

--- Get detailed job information for a player.
-- @param source number: The player's server ID.
-- @return table: A table containing job details (name, label, grade, and gradeName).
GetPlayerJobInfo = function(source)
    local player = ESX.GetPlayerFromId(source)
    local job = player.getJob()
    local jobInfo = {
        name = job.name,
        label = job.label,
        grade = job.grade,
        gradeName = job.grade_label,
    }
    return jobInfo
end

--- Get gang information for a player (always false).
-- @param source number: The player's server ID.
-- @return boolean: Always returns false.
GetPlayerGangInfo = function(source)
    return false
end

--- Get all players and their basic information.
-- @return table: A list of players with job, gang, and source information.
GetPlayers = function()
    local players = ESX.GetExtendedPlayers()
    local formattedPlayers = {}
    for _, v in pairs(players) do
        local player = {
            job = v.getJob().name,
            gang = false,
            source = v.source
        }
        table.insert(formattedPlayers, player)
    end
    return formattedPlayers
end

--- Get the player's date of birth.
-- @param source number: The player's server ID.
-- @return string: The player's date of birth.
GetDob = function(source)
    local player = ESX.GetPlayerFromId(source)
    return player.variables.dateofbirth
end

--- Get the player's sex.
-- @param source number: The player's server ID.
-- @return string: The player's sex.
GetSex = function(source)
    local player = ESX.GetPlayerFromId(source)
    return player.variables.sex
end

--- Remove an item from a player's inventory.
-- @param source number: The player's server ID.
-- @param item string: The item's name.
-- @param count number: The quantity to remove.
-- @return boolean: True if the item was removed, false otherwise.
RemoveItem = function(source, item, count)
    local player = ESX.GetPlayerFromId(source)
    return player.removeInventoryItem(item, count)
end

--- Add an item to a player's inventory.
-- @param source number: The player's server ID.
-- @param item string: The item's name.
-- @param count number: The quantity to add.
-- @return boolean: True if the item was added, false otherwise.
AddItem = function(source, item, count)
    local player = ESX.GetPlayerFromId(source)
    return player.addInventoryItem(item, count)
end

--- Check if a player has a specific item.
-- @param source number: The player's server ID.
-- @param _item string: The item's name.
-- @return number: The amount of the item the player has.
HasItem = function(source, _item)
    local player = ESX.GetPlayerFromId(source)
    local item = player.getInventoryItem(_item)
    return item and (item.amount or item.count or 0) or 0
end

--- Get a player's inventory.
-- @param source number: The player's server ID.
-- @return table: A list of inventory items with details (name, label, count, weight, metadata).
GetInventory = function(source)
    local player = ESX.GetPlayerFromId(source)
    local items = {}
    local data = ox_inventory and exports.ox_inventory:GetInventoryItems(source) or player.getInventory()
    for i = 1, #data do
        local item = data[i]
        items[#items + 1] = {
            name = item.name,
            label = item.label,
            count = ox_inventory and item.count or item.amount,
            weight = item.weight,
            metadata = ox_inventory and item.metadata or item.info
        }
    end
    return items
end

--- Register a usable item.
-- @param item string: The item's name.
-- @param cb function: The callback function triggered when the item is used.
RegisterUsableItem = function(item, cb)
    ESX.RegisterUsableItem(item, cb)
end

GetMoney = function(src, accountname)
    local xPlayer = ESX.GetPlayerFromId(src)
    if accountname == 'cash' then
        return tonumber(xPlayer.getAccount("money").money)
    elseif accountname == 'bank' then
        return tonumber(xPlayer.getAccount("bank").money)
    end
end

AddMoney = function(src, accountname, amount, reason)
    local xPlayer = ESX.GetPlayerFromId(src)
    if accountname == 'cash' then
        xPlayer.addAccountMoney("money", amount)
        return true
    elseif accountname == 'bank' then
        xPlayer.addAccountMoney("bank", amount)
        return true
    end
end

RemoveMoney = function(src, accountname, amount, reason)
    local xPlayer = ESX.GetPlayerFromId(src)
    if accountname == 'cash' then
        if GetMoney(src, accountname) >= tonumber(amount) then
            xPlayer.removeAccountMoney("money", amount)
            return true
        end
        return false
    elseif accountname == 'bank' then
        if GetMoney(src, accountname) >= tonumber(amount) then
            xPlayer.removeAccountMoney("bank", amount)
            return true
        end
        return false
    end
end