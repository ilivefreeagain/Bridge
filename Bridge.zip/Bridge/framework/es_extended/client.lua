local ESX = exports.es_extended:getSharedObject()
local PlayerData = ESX.GetPlayerData()
local isDead


getItemTable = function(item)
    return nil
end

--- Display a notification to the player.
-- @param msg string: The message to display.
-- @param type string: The type of notification.
-- @param duration number: The duration of the notification.
bridgeNotify = function(msg, type, duration)
    ESX.ShowNotification(msg, type, duration)
end

--- Get the player's job and gang information.
-- @return string, boolean: The player's job name and gang status (always false).
GetPlayerGroups = function()
    return PlayerData.job.name, false
end

--- Get detailed job information for the player.
-- @return table: A table containing job details (name, grade, label).
GetPlayerGroupInfo = function()
    local jobInfo = {
        name = PlayerData.job.name,
        grade = PlayerData.job.grade,
        label = PlayerData.job.label
    }
    return jobInfo
end

--- Get the player's sex.
-- @return number: 1 for Male, 2 for Female.
GetSex = function()
    if not PlayerData.sex then
        PlayerData = ESX.GetPlayerData()
    end
    return PlayerData.sex == 'm' and 1 or 2
end

--- Check if the player is dead.
-- @return boolean: True if the player is dead, false otherwise.
IsDead = function()
    return isDead
end

--- Set the player's outfit.
-- @param outfit table: The outfit data to apply.
SetOutfit = function(outfit)
    if outfit then
        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
            TriggerEvent('skinchanger:loadClothes', skin, outfit)
        end)
    else
        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
            TriggerEvent('skinchanger:loadSkin', skin)
        end)
    end
end



--- Event handler for player spawn.
-- Resets the isDead variable.
AddEventHandler('esx:onPlayerSpawn', function(noAnim)
    isDead = nil

    TriggerEvent(GetCurrentResourceName()..':Client:OnPlayerLoaded')

    TriggerEvent(GetCurrentResourceName()..':Client:onResourceStart')
end)

--- Event handler for job changes.
-- Updates the PlayerData with the new job.
RegisterNetEvent('esx:setJob', function(job)
    PlayerData.job = job
end)

--- Event handler for player death.
-- Sets isDead to true and triggers a playerDied event.
AddEventHandler('esx:onPlayerDeath', function(data)
    isDead = true
    TriggerEvent('stevo_lib:playerDied')
end)

--- Event handler for player loaded.
-- Updates PlayerData and triggers a playerLoaded event.
RegisterNetEvent('esx:playerLoaded', function()
    PlayerData = ESX.GetPlayerData()
    TriggerEvent('stevo_lib:playerLoaded')
end)
